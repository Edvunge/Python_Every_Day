# Strings

mensagem = "ola Adriana!"
mensagem1 = "ola paulo!"
#print(mensagem1) 
print(mensagem + " " + mensagem1) #concatenação