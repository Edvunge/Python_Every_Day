#print(5 + 8)

#print(9 - 8)

#print(2 * 3)

#print(88 / 4)

#print(7 ** 1)

#print(7 % 1)

#print((1 + 3) * 2 )

# bool
# true ( 5 + 5) 10
# false ( 5 + 15) 10

print(8 == 8)
# 8 == 9 igualdade
# r =  6 atribuiçao
#  

print(0 and 2)
#  0 and 2 ( e )

print(4 or 5)
# 4 or 5 ( ou ) 


print(1 == 1) #True
print(1 == 12) #False

print(2 + 7 == 1 + 8 == 5 * 2)

print(1 != 21)

print(1 < 21) 

print(21 > 34)

print(3 >= 2) #

print(3 <= 2) #